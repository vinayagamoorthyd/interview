import {Component,Input,Output,EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'comment-mange-dir',
  template:`
  <div class="bg-popup">
  <form  [formGroup]="createCommntForm" class="login-form">
    <div class="form-group form-inline">
      <label class="col-md-4"> Names </label>
      <input type="text" class="form-control col-md-8" formControlName="userName" />
    </div>
    <div class="form-group form-inline">
      <label class="col-md-4"> Phone No</label>
      <input type="number" class="form-control col-md-8" formControlName="phoneNumber" />
    </div>
    <div class="form-group form-inline">
      <label class="col-md-4"> Email</label>
      <input type="email" class="form-control col-md-8"formControlName="email" />
    </div>
    <div class="form-group form-inline">
      <label class="col-md-4"> Title</label>
      <input type="text" class="form-control col-md-8" formControlName="title"/>
    </div>
    <div class="form-group form-inline">
      <label class="col-md-4"> Date</label>
      <input type="text" class="form-control col-md-8" formControlName="date">
    </div>
    <div class="alert alert-danger" *ngIf="formErrors?.length>0">
     <ul>
       <li *ngFor="let item of formErrors">{{item}}</li>
     </ul>
    </div>
    <div class="form-group form-inline">
      <label class="col-md-5"> </label>
      <button type="button" class="btn btn-primary" (click)="bindData()"> Submit</button> &nbsp; <button type="button" (click)='formDisplay.emit(false)' class="btn btn-primary"> Cancel</button>
    </div>
  </form>
  </div>
  `
})

export class  CommentMangeDir {
  private records:any={
    title:'',
    comment:'',
    date:'',
    _id:''
  };
public formErrors:any=[];
  public createCommntForm=new FormGroup({
    userName:new FormControl('',Validators.required),
    phoneNumber:new FormControl('',[ Validators.required, Validators.minLength(10), Validators.maxLength(12)]),
    email:new FormControl('',[Validators.required,Validators.email]),
    title:new FormControl('',[Validators.required, Validators.minLength(8)]),
    date:new FormControl('', Validators.required)

  });

  @Input('cid') __cid:number;
  @Output() formDisplay: EventEmitter<boolean>=new EventEmitter();
  @Output() formData: EventEmitter<any> = new EventEmitter();
  bindData(){
    console.log(this.createCommntForm.valid, this.createCommntForm.controls['userName'].valid, this.createCommntForm.value)

this.formErrors=[];
if(this.createCommntForm.valid!=true){
  if(this.createCommntForm.controls['userName'].valid!=true){
    (this.formErrors).push('Name must !');
  }
  if(this.createCommntForm.controls['email'].valid!=true){
    (this.formErrors).push('Email must !');
  }

}

if( (this.formErrors).length>0 ){
  return 0;
}



    this.records['_id']=Math.floor(Date.now() / 10000);
     this.formData.emit(this.records);
     this.formDisplay.emit(false);
  }


  constructor(){

  }
}
