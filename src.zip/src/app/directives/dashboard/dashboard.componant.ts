import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  template: `
  <top-nav></top-nav>
  <div class="container-fluid">
    <div class="row">
    <div class="col-md-3">
      <left-nav></left-nav>
      </div>

  <div class="col-md-9 data-content">
    <img src="../app/images/welcome-bg.png" alt="welcome" />
  </div>
 `,
  styles:[`
    .container{width:100%;}
    .left-sidebar{ background:#fff;min-height:600px; box-shadow: 0px 4px 4px #ddd;}
    .left-sidebar a {float:left; width:100%;padding:20px 10px; }
    .icons{ text-align:right;}
    .icons div{float:left;}
    .navbar-brand{color:#fff !important}
    `]

})
export class DashboardPage {

}
