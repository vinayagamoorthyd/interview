"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var DashboardPage = (function () {
    function DashboardPage() {
    }
    return DashboardPage;
}());
DashboardPage = __decorate([
    core_1.Component({
        template: "\n  <top-nav></top-nav>\n  <div class=\"container-fluid\">\n    <div class=\"row\">\n    <div class=\"col-md-3\">\n      <left-nav></left-nav>\n      </div>\n\n  <div class=\"col-md-9 data-content\">\n    <img src=\"../app/images/welcome-bg.png\" alt=\"welcome\" />\n  </div>\n ",
        styles: ["\n    .container{width:100%;}\n    .left-sidebar{ background:#fff;min-height:600px; box-shadow: 0px 4px 4px #ddd;}\n    .left-sidebar a {float:left; width:100%;padding:20px 10px; }\n    .icons{ text-align:right;}\n    .icons div{float:left;}\n    .navbar-brand{color:#fff !important}\n    "]
    })
], DashboardPage);
exports.DashboardPage = DashboardPage;
//# sourceMappingURL=dashboard.componant.js.map