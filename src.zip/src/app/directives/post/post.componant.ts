import { Component } from '@angular/core';


@Component({
  templateUrl: `./view.post.html`
})

export class postPages  {

}
