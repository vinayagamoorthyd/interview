import { Component } from '@angular/core';


@Component({
  templateUrl: `./view.dashboard.html`
})
export class DashboardPage {

}
