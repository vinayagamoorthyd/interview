"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var api_service_1 = require("./../../services/api/api.service");
var commentsPage = (function () {
    function commentsPage(api) {
        this.api = api;
        this.comments = {};
        this.displayForm = false;
        this.comments = [
            {
                'title': 'Angular Feature',
                'comment': 'Angular Feature',
                'date': '10/08/2017',
                '_id': '01'
            },
            {
                'title': 'Angular Feature',
                'comment': 'Angular Feature',
                'date': '13/08/2017',
                '_id': '02'
            },
        ];
    }
    commentsPage.prototype.getnewData = function () {
        this.api.rest().then(function (respon) {
        });
    };
    commentsPage.prototype.fetchData = function () {
        var _this = this;
        this.api.test().then(function (res) {
            _this.users = res;
            console.log('res', res);
        });
    };
    commentsPage.prototype.insertData = function (data) {
        (this.comments).push(data);
    };
    return commentsPage;
}());
commentsPage = __decorate([
    core_1.Component({
        templateUrl: "./view.comments.html"
    }),
    __metadata("design:paramtypes", [api_service_1.ApiService])
], commentsPage);
exports.commentsPage = commentsPage;
//# sourceMappingURL=comments.componant.js.map