import { Component } from '@angular/core';
import { Router, RouterLinkActive } from '@angular/router';


@Component({
  selector : 'left-nav',
  template: `<div class="left-sidebar">
      <a [class.active]="router.isActive('/commentsPage')"
      [routerLink]="['/commentsPage']" class="btn btn-default">Comment</a>

      <a  [class.active]="router.isActive('/postPage')"
      [routerLink]="['/postPage']" class="btn btn-default">Post</a>

  </div>`

})

export class leftNavigation {
  constructor(public router:Router){

  }
}
