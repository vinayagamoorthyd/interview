import { Component } from '@angular/core';


@Component({
  selector : 'top-nav',
  template: `<nav class="navbar navbar-light bg-primary justify-content-between">
    <a class="navbar-brand">Welcome sAdmin</a>
    <!-- form class="form-inline">
    <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-default my-2 my-sm-0" type="submit">Search</button>
    </form -->
    <div class="pull-right"><a class="navbar-brand" (click)="logout()">Logout</a></div>
  </nav>`
})
export class topNavigation {

}
