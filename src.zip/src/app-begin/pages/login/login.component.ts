import { Component } from '@angular/core';
import { FormGroup,FormControl,Validators,FormBuilder} from '@angular/forms';


@Component({
  template: `
  <form  [formGroup]="loginForm" >
    <input type="text" placeholder="name" formControlName="name" />
    <input type="text" placeholder="password"  formControlName="password"/>
    <p >{{counter}}</p>
    <button (click)="login()">Login</button>
</form>
  `
})
export class loginPage  {
  constructor(public fb:FormBuilder){

  }

  public loginForm=this.fb.group({
    name: ['',Validators.required],
    password: ['',[Validators.required,Validators.minLength(3)] ]
  });

  login(){ console.log('---');
    console.log(this.loginForm.valid, this.loginForm.value);
  }
}
