import { Component } from '@angular/core';


@Component({
  selector : 'top-nav',
  template: `<nav class="navbar navbar-light bg-primary justify-content-between">
    <a class="navbar-brand">Welcome Admin</a>
    <!-- form class="form-inline">
    <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-default my-2 my-sm-0" type="submit">Search</button>
    </form -->
  </nav>`
})
export class topNavigation {

}
